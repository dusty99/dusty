Note: I don't own the api credits go to the Nihon creators for the api that im using, I couldn't find a good api thats really annoying and i just came across this one.

This is just a little exploit I made because I was bored.

What the buttons do if you aren't familiar with what they do:
Execute - Executes the script that is inside of the editor.
Clear - Clears the editor.
Open File - Open a lua/txt file to load into the editor.
Save File - Saves whatever is inside the editor.
Execute File - Executs a lua/txt file.
Script Hub - Runs owl hub( so lazy to make my own )
Attach - Attaches the exploit to Roblox so you can execute scripts and stuff.
Gear button - Refreshes the exploits script list on the right.

How to load/execute the scripts from the script list:
This is really simple you just right click on the script that you want to execute/load and there will be some options to choose from( execute/load ).